# Command Line Corn Maze
### Created by [Your Name]

## Instructions:
1. Use the `cd` command to navigate through the maze.
2. Use the `ls` command to list directories and files.
3. Use the `cat` command to read clues from files.
4. LOOK EVERYWHERE, oh and use grep if needed (Premier League?!?!?!?).

Good luck!